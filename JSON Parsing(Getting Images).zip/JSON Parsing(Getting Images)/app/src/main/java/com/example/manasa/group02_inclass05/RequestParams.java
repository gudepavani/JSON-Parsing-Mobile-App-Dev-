package com.example.manasa.group02_inclass05;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

/**
 * Created by Manasa on 9/19/2016.
 */
public class RequestParams {String method, baseURL;

    public RequestParams(String method, String baseURL) {
        this.method = method;
        this.baseURL = baseURL;
    }

    HashMap<String, String> params = new HashMap<String, String>();

    public void AddParams(String key, String value)
    {
        params.put(key, value);
    }

    public String GetEncodedParameters() throws UnsupportedEncodingException {

        StringBuilder sb = new StringBuilder();
        for (String key : params.keySet()) {
            try {
                String value = URLEncoder.encode(params.get(key), "UTF-8");
                if (sb.length() > 0) {
                    sb.append("&");
                }
                sb.append(key + "=" + value);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public String GetEncodedUrl()
    {
        try {
            return this.baseURL + "?" + GetEncodedParameters();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }return null;

    }

    public HttpURLConnection SetUpConnection() throws IOException {
        URL url = new URL(GetEncodedUrl());
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();
        connection.setRequestMethod("GET");
        return connection;
    }
}
