package com.example.manasa.group02_inclass05;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Manasa on 9/19/2016.
 */

public class GetImage extends AsyncTask<String, Void, Bitmap>{

IData activity;
    ProgressDialog pd;
    public GetImage(IData activity){
        this.activity = activity;
    }
    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);

    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        //super.onPostExecute(bitmap);
        activity.setUpData(bitmap);
        pd.dismiss();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        Context c = activity.getContext();
        pd = new ProgressDialog(c);
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setCancelable(false);
        pd.setMessage("Loading Dictionary . . . ");
        pd.show();
    }

    @Override
    protected Bitmap doInBackground(String... params) {

        URL url = null;
        BufferedReader reader = null;
        try {
            url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            //con.connect();
            Bitmap image = BitmapFactory.decodeStream(con.getInputStream());
            return image;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;
    }

    static public interface IData
    {
        public void setUpData(Bitmap bitmap);
        public Context getContext();
    }
}
