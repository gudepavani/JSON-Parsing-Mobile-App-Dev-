package com.example.manasa.group02_inclass05;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements GetImage.IData {

    ImageButton next, previous;
    int index;

    AlertDialog.Builder builder;
    String[] choice = new String[]{
            "UNCC", "Android", "Winter", "Aurora", "Wonders"
    };
    String[] URLString;
    Button Go;
    TextView SearchKeyword;

    ImageView mainImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SearchKeyword = (TextView) findViewById(R.id.keywordSearch);
        Go = (Button) findViewById(R.id.goButton);
        next = (ImageButton) findViewById(R.id.nextButton);
        previous = (ImageButton) findViewById(R.id.prevButton);

        next.setEnabled(false);
        previous.setEnabled(false);

        mainImage = (ImageView) findViewById(R.id.image);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! isConnectedOnline()) {
                    Toast.makeText(MainActivity.this, "No Internet Connection!", Toast.LENGTH_LONG).show();
                }
                else {
                    if (index < URLString.length - 1) {
                        index++;
                        new GetImage(MainActivity.this).execute(URLString[index]);

                    }
                    else {
                        index = 1;
                        new GetImage(MainActivity.this).execute(URLString[index]);
                    }
                }


            }
        });

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (! isConnectedOnline()) {
                    Toast.makeText(MainActivity.this, "No Internet Connection!", Toast.LENGTH_LONG).show();
                }
                else {
                    if (index > 1) {
                        index--;
                        new GetImage(MainActivity.this).execute(URLString[index]);

                    } else {
                        index = URLString.length - 1;
                        new GetImage(MainActivity.this).execute(URLString[index]);
                    }
                }}
        });
        SearchKeyword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose a Keyword").setCancelable(true).setItems(choice, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SearchKeyword.setText(choice[which]);
                    }
                }).show();
            }
        });
        Go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnectedOnline()) {
                    RequestParams param = new RequestParams("GET", "http://dev.theappsdr.com/apis/photos/index.php");
                    param.AddParams("keyword", SearchKeyword.getText().toString());
                    new GetURL().execute(param);
                }
                else {
                    Toast.makeText(MainActivity.this, "No Internet Connection!", Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    private boolean isConnectedOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo nwi = cm.getActiveNetworkInfo();
        if (nwi != null && nwi.isConnected()) {
            // Log.d("Demo","YES Net");
            return true;

        }
        //Log.d("Demo","No");
        return false;
    }

    @Override
    public void setUpData(Bitmap bitmap) {
        mainImage.setImageBitmap(bitmap);
        Log.d("demo", bitmap.toString());

    }

    @Override
    public Context getContext() {
        return this;

    }

    public class GetURL extends AsyncTask<RequestParams, Void, String> {


        @Override
        protected String doInBackground(RequestParams... params) {
            URL url = null;
            BufferedReader reader = null;
            try {

                //url = new URL(params[0]);
                HttpURLConnection con = params[0].SetUpConnection();

                con.setRequestMethod("GET");
                //con.connect();

                reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                //con.getInputStream();
                StringBuilder sb = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                return sb.toString();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String URL) {
            if (URL != null) {
                URLString = URL.split(";");
                new GetImage(MainActivity.this).execute(URLString[1]);
                index = 1;
                next.setEnabled(true);
                previous.setEnabled(true);
            }
            else {
                Toast.makeText(MainActivity.this, "No Image is Found!", Toast.LENGTH_LONG).show();
            }



        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
    }


}
